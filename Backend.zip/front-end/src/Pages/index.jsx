import React from "react";
import Home from "../Pages/Home/Home";
import Signup from "../Pages/Signup/Signup";
import AccountPage from "../Pages/AccountPage/AccountPage.jsx";

import Header from "../Component/Header/Header";
import Footer from "../Component/Footer/Footer";
import { BrowserRouter, HashRouter, Routes, Route } from "react-router-dom";
import { useState, createContext } from "react";

export const UserContext = React.createContext();

export default function Index() {
  const [user, setUser] = useState();
  const accountPage = !user ? <Signup /> : <AccountPage />;
  return (
    <HashRouter basename="/">
      <UserContext.Provider value={{ user, setUser }}>
        <Header />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/account" element={accountPage} />
        </Routes>
        <Footer />
      </UserContext.Provider>
    </HashRouter>
  );
}
