import {
  Container,
  Image,
  H1,
  SignupForm,
  Form,
  Input,
  Button,
} from "./Styles/Signup";
import spinner from "../../public/Assets/img/spinner-6.png";
import grasshopperLaptop from "../../public/Assets/img/grasshopperLaptop.svg";

import { UserContext } from "../../Pages/index";
import { useEffect, useState, useContext } from "react";

export default function Signup() {
  const [isLoading, setIsLoading] = useState(+false);
  const [isFormSuccessful, setIsFormSuccessful] = useState(+true);
  const user = useContext(UserContext);

  let handleForm = (e) => {
    e.preventDefault();
    setIsLoading(+true);
    const myFormData = new FormData(e.target);
    const formDataObj = {};
    myFormData.forEach((value, key) => (formDataObj[key] = value));

    fetch("http://localhost:8000/customers?admin=true", {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      method: "POST",
      body: JSON.stringify(formDataObj),
    })
      .then((response) => {
        return response;
      })
      .then((data) => {
        if (data.ok) {
          console.log(data);
          setIsLoading(+false);
          user.setUser(formDataObj["prénom"]);
          console.log(user.user);
        }
      })
      .catch((res) => {
        console.log(res);
        setIsLoading(+false);
        setIsFormSuccessful(+false);
      });
  };
  useEffect(() => {
    document.querySelectorAll(".addClass").forEach((elem) => {
      elem.classList.add("--active");
    });
  }, []);
  return (
    <Container className="App">
      <SignupForm className="addClass">
        <div>
          <H1>Créer un nouveau compte</H1>
          <Form onSubmit={(e) => handleForm(e)} autoComplete="false">
            <Input>
              <span className="material-symbols-outlined material-icons">
                badge
              </span>
              <input
                type="text"
                name="prénom"
                placeholder="Prénom"
                required
              ></input>
            </Input>
            <Input>
              <span className="material-symbols-outlined material-icons">
                badge
              </span>
              <input type="text" name="nom" placeholder="Nom" required></input>
            </Input>
            <Input>
              <span className="material-symbols-outlined material-icons">
                badge
              </span>
              <input
                type="email"
                name="e-mail"
                placeholder="Courriel"
                required
              ></input>
            </Input>
            <Input>
              <span className="material-symbols-outlined material-icons">
                badge
              </span>
              <input
                type="password"
                name="password"
                placeholder="Mot de passe"
                required
              ></input>
            </Input>
            <Input>
              <span className="material-symbols-outlined material-icons">
                military_tech
              </span>
              <input
                type="date"
                max="2022-01-01"
                name="birthday"
                placeholder="Anniversaire"
                required
              ></input>
            </Input>
            <Input>
              <span className="material-symbols-outlined material-icons">
                home
              </span>
              <input
                type="text"
                name="address"
                placeholder="Adresse"
                required
              ></input>
            </Input>
            <div>
              <input type="checkbox" required></input>
              <small> I read and agree to Terms & Conditions</small>
            </div>
            {!isLoading ? (
              <Button type="submit" className="cta-button start-coding">
                S'inscrire
              </Button>
            ) : (
              <Button
                type="submit"
                disabled
                className="cta-button start-coding"
                y
              >
                <img src={spinner} className="loading" alt="loading"></img>
              </Button>
            )}
            {!isFormSuccessful && (
              <small>Une erreur s’est produite lors de l'inscription</small>
            )}
          </Form>
        </div>
      </SignupForm>
      <Image className="addClass">
        <img src={grasshopperLaptop} alt={grasshopperLaptop}></img>
      </Image>
    </Container>
  );
}
