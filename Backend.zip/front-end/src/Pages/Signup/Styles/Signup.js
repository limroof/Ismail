import styled from "styled-components";
import { keyframes } from "styled-components";

export const Container = styled.section`
  width: 100%;
  display: flex;
  height: calc(100vh - 40px - 100px);
  min-height: 500px;
  max-height: 1000px;
  align-items: center;
  max-width: 1200px;
  margin: auto;
`;
export const Banner = styled.div`
  background-image: linear-gradient(45deg, #3f51b5, #9b00e8);
  display: flex;
  justify-content: center;
  align-items: center;
  transition-property: border, witdh;
  transition: 0.5s ease-out;
  width: 100%;
  &.active {
    border-top-right-radius: 7%;
    border-bottom-right-radius: 7%;
    width: 40%;
    min-width: 400px;
    width: 40%;
  }
`;
const ScaleMoveLeft = keyframes`
  0% {
      transform: scale(1.5) translatex(200%);
  }
  100% {
      transform: scale(1) translatex(0%);
    }
`;

export const Image = styled.div`
  width: 50%;
  min-height: 500px;
  display: flex;
  align-items: center;
  position: relative;
  transform: scale(1.5) translatex(200%);
  &.--active {
    animation: ${ScaleMoveLeft} 1s ease-out 1 forwards;
    animation-delay: 0.5s;
  }
  img {
    position: absolute;
    left: 0;
    width: 200%;
  }
`;

export const H1 = styled.h1`
  color: #002c43;
  font-size: 36px;
  font-weight: 500;
  margin-bottom: 20px;
  margin-top: 0;
  line-height: 46px;
`;

const ScaleMoveRight = keyframes`
    0% {
    transform: scale(0);
    }
    100% {
    transform: scale(1);
    }
`;
export const SignupForm = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  overflow: hidden;
  width: 60%;
  min-height: 100%;
  transform: scale(0);
  &.--active {
    animation: ${ScaleMoveRight} 0.5s ease-out 1 forwards;
  }
`;

export const Form = styled.form`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  row-gap: 20px;
`;

export const Input = styled.div`
  position: relative;
  width: 100%;
  border: none;
  display: flex;
  align-items: center;
  > input {
    border: none;
    height: 100%;
    padding-left: 50px;
    padding-right: 20px;
    min-height: 40px;
    border-radius: 25px;
    box-shadow: 0px 10px 49px -14px rgba(0, 0, 0, 0.7);
    font-size: 18px;
  }
  span {
    position: absolute;
    left: 15px;
    pointer-events: none;
  }
`;

const Loading = keyframes`
    0% {
    transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
`;

export const Button = styled.button`
  height: 54px;
  width: 100%;
  &:active {
    transform: scale(0.98);
  }
  &:hover {
    opacity: 0.92;
  }
  > img {
    height: 100%;
    &.loading {
      animation: ${Loading} 0.5s linear infinite;
    }
  }
`;
