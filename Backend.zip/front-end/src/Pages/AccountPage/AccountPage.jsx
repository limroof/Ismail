export default function AccountPage() {
  return <div className="App">toto</div>;
}
