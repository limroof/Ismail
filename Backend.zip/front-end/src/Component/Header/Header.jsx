import React from "react";
import {
  Headerh,
  TopBar,
  Nav,
  MobileNav,
  ImgLogo,
  StyledLink,
  Drawer,
  Burger,
  CloseIcon,
} from "./Styles/StylesHeader";
import menuIcon from "../../public/Assets/img/menu-icon.svg";
import closeIcon from "../../public/Assets/img/close-icon.svg";
import gh_icon from "../../public/Assets/img/gh_icon.svg";

import { useEffect, useState } from "react";
import { useContext } from "react";
import { UserContext } from "../../Pages";

export default function Header() {
  const [isDrawerOpen, setDrawer] = useState(false);
  const user = useContext(UserContext);

  useEffect(() => {
    document.getElementById("topBar").classList.add("--active");
  }, []);

  const openDrawer = () => {
    document.querySelector("body").classList.add("--no-scroll");
    setDrawer(true);
  };

  const closeDrawer = () => {
    document.getElementById("topBar").classList.remove("--active--mobile");
    document.querySelector("body").classList.remove("--no-scroll");
    document.querySelectorAll("a.AnimateOpen").forEach((elem) => {
      elem.classList.add("AnimateClose");
    });
    document.getElementById("drawer").classList.add("--closing");
    setTimeout(() => {
      setDrawer(false);
    }, 2000);
  };

  return (
    <Headerh>
      <TopBar id="topBar">Now available in French!</TopBar>
      <Nav>
        <StyledLink to="/">
          <ImgLogo />
        </StyledLink>
        <StyledLink to="/why-coding">What is Coding</StyledLink>
        <StyledLink to="/curriculum/fundamentals-1">Curriculum</StyledLink>
        <StyledLink to="/glossary/data-types">Glossary</StyledLink>
        <StyledLink to="/about">About Us</StyledLink>
        <StyledLink to="/faq">FAQ</StyledLink>
        <StyledLink to="/account" className="Signin">
          {!user.user ? "S'inscrire" : `Bonjour ${user.user}`}
        </StyledLink>
      </Nav>

      <MobileNav>
        <ImgLogo />
        {isDrawerOpen && (
          <Drawer id="drawer">
            <CloseIcon
              onClick={() => {
                closeDrawer();
              }}
            >
              <img src={closeIcon} alt={menuIcon}></img>
            </CloseIcon>
            <StyledLink to="/" className="AnimateOpen">
              <img src={gh_icon} alt={gh_icon}></img>
            </StyledLink>
            <StyledLink to="/why-coding" className="AnimateOpen">
              What is Coding
            </StyledLink>
            <StyledLink to="/curriculum/fundamentals-1" className="AnimateOpen">
              Curriculum
            </StyledLink>
            <StyledLink to="/glossary/data-types" className="AnimateOpen">
              Glossary
            </StyledLink>
            <StyledLink to="/about" className="AnimateOpen">
              About Us
            </StyledLink>
            <StyledLink to="faq" className="AnimateOpen">
              FAQ
            </StyledLink>
            <button className="cta-button start-coding">Get the app</button>
          </Drawer>
        )}

        <Burger
          onClick={() => {
            openDrawer();
          }}
        >
          <img src={menuIcon} alt={menuIcon}></img>
        </Burger>
      </MobileNav>
    </Headerh>
  );
}
